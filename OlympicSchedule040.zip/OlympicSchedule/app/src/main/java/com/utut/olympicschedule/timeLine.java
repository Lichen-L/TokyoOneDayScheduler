package com.utut.olympicschedule;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;

public class timeLine extends AppCompatActivity {
    static String datePassed;
    private int lengthGame;
    private int offsetToWP;
    private String gameName;
    private String WPoint;
    private Button slotButton;
    private GlobalApplication appli;
    FrequentUsedMethods frequentUsedMethods = new FrequentUsedMethods(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_line);

        Intent intent = getIntent();
        datePassed = intent.getStringExtra("date");

        Toolbar toolbar = findViewById(R.id.toolbarTimeLine);
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolbarLayout = findViewById(R.id.toolbarLayoutTimeline);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarLayout.setTitle(datePassed);
        toolbarLayout.setTitleEnabled(true);
        toolbarLayout.setExpandedTitleColor(Color.WHITE);
        toolbarLayout.setCollapsedTitleTextColor(Color.WHITE);

        FloatingActionButton fab = findViewById(R.id.fabTimeLine);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(timeLine.this, chooseSportToAdd.class);
                intent.putExtra("date",datePassed);
                startActivity(intent);
            }
        });

        frequentUsedMethods.setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
    }

    @Override
    protected void onResume(){
        super.onResume();
        appli = (GlobalApplication) timeLine.this.getApplication();
        if(appli.getFlag()) {
            offsetToWP = (int) appli.getMap().get("offsetToWP");
            lengthGame = (int) appli.getMap().get("lengthGame");
            gameName = (String) appli.getMap().get("gameName");
            WPoint = (String) appli.getMap().get("WP");

            int lineConstId = getResources().getIdentifier("line"+ WPoint, "id", getPackageName());
            int textConstId = getResources().getIdentifier("text"+ WPoint, "id", getPackageName());

            slotButton = frequentUsedMethods.createButtonWithConstraint(R.id.ConsLayoutTimeline, this, gameName, 280, lengthGame,
                    lineConstId, textConstId, offsetToWP, 20);
            slotButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            });
            appli.setFlag(false);
        }

        if(appli.getIntentDelete()){
            ViewGroup parentLayout = (ViewGroup) slotButton.getParent();
            parentLayout.removeView(slotButton);
            appli.setIntentDelete(false);
        }
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        int itemId = item.getItemId();
        if (itemId == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
 }
