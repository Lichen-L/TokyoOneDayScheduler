package com.utut.olympicschedule;

import android.app.Activity;
import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class FrequentUsedMethods {

    public Activity activity;

    public FrequentUsedMethods(Activity _activity){
        this.activity = _activity;
    }

    public Button createButtonWithConstraint(int layoutId, Context targetContext, String buttonText, int width, int height, int topConstrainId, int startConstrainId, int topMargin, int startMargin){
        ConstraintLayout constraintLayout = this.activity.findViewById(layoutId);

        Button button = new Button(targetContext);
        button.setText(buttonText);
        button.setBackgroundColor(this.activity.getResources().getColor(R.color.colorAccent));
        button.setTextColor(this.activity.getResources().getColor(R.color.white));
        int buttonId = View.generateViewId();
        button.setId(buttonId);

        constraintLayout.addView(button);

        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(constraintLayout);

        DisplayMetrics metrics = targetContext.getResources().getDisplayMetrics();

        constraintSet.constrainWidth(button.getId(), (int) (width * metrics.density));
        constraintSet.constrainHeight(button.getId(), (int) (height * metrics.density));

        constraintSet.connect(button.getId(), ConstraintSet.TOP, topConstrainId, ConstraintSet.BOTTOM, (int) (topMargin * metrics.density));
        constraintSet.connect(button.getId(), ConstraintSet.START, startConstrainId, ConstraintSet.END, (int) (startMargin * metrics.density));
        constraintSet.applyTo(constraintLayout);

        return button;
    }

    public Button createButtonWithConstraint_Frag(ConstraintLayout constraintLayout, Context targetContext, String buttonText, int width, int height, int topConstrainId, int startConstrainId, int topMargin, int startMargin){
        Button button = new Button(targetContext);
        button.setText(buttonText);
        button.setBackgroundColor(this.activity.getResources().getColor(R.color.colorAccent));
        button.setTextColor(this.activity.getResources().getColor(R.color.white));
        int buttonId = View.generateViewId();
        button.setId(buttonId);

        constraintLayout.addView(button);

        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(constraintLayout);

        DisplayMetrics metrics = targetContext.getResources().getDisplayMetrics();

        constraintSet.constrainWidth(button.getId(), (int) (width * metrics.density));
        constraintSet.constrainHeight(button.getId(), (int) (height * metrics.density));

        constraintSet.connect(button.getId(), ConstraintSet.TOP, topConstrainId, ConstraintSet.BOTTOM, (int) (topMargin * metrics.density));
        constraintSet.connect(button.getId(), ConstraintSet.START, startConstrainId, ConstraintSet.END, (int) (startMargin * metrics.density));
        constraintSet.applyTo(constraintLayout);

        return button;
    }

    public static void setWindowFlag(Activity activity, final int bits, boolean on) {
        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits; // ~ → inverse
        }
        win.setAttributes(winParams);
    }
}
