package com.utut.olympicschedule;

import android.app.Application;

import java.util.Map;

public class GlobalApplication extends Application {
    //private static int gameCount;
    private boolean flag = false;
    private boolean intentDelete = false;
    private Map map;

    public boolean getFlag(){
        return flag;
    }

    public void setFlag(boolean _flag) {
        this.flag = _flag;
    }

    public boolean getIntentDelete(){
        return intentDelete;
    }

    public void setIntentDelete(boolean _intentDelete) {
        this.intentDelete = _intentDelete;
    }

    public Map getMap(){
        return map;
    }

    public void setMap(Map _Map) {
        this.map = _Map;
    }

}
