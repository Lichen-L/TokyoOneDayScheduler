package com.utut.olympicschedule;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

import java.util.HashMap;
import java.util.Map;

public class game3vs3Information extends AppCompatActivity {
    private Map toBePassedMap = new HashMap<String, Object>();
    private boolean ifClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game3vs3_information);

        Intent intent = getIntent();
        String gameName = intent.getStringExtra("gameName");
        String wholePoint = intent.getStringExtra("wholePoint");
        int lengthGame = intent.getIntExtra("lengthGame", 60);
        int offsetToWP = intent.getIntExtra("offsetToWP", 0);

        toBePassedMap.put("gameName", gameName);
        toBePassedMap.put("lengthGame", lengthGame);
        toBePassedMap.put("offsetToWP", offsetToWP);
        toBePassedMap.put("WP",wholePoint);

        Toolbar toolbar = findViewById(R.id.toolbarBasketball3vs3);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        CollapsingToolbarLayout toolbarLayout = findViewById(R.id.toolbarLayoutBasketball3vs3);

        toolbarLayout.setTitle(gameName);
        toolbarLayout.setTitleEnabled(true);
        toolbarLayout.setExpandedTitleColor(Color.WHITE);
        toolbarLayout.setCollapsedTitleTextColor(Color.WHITE);

        FrequentUsedMethods frequentUsedMethods = new FrequentUsedMethods(this);
        frequentUsedMethods.setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);

        final FloatingActionButton fab = findViewById(R.id.fabBasketball3vs3);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalApplication appli = (GlobalApplication) game3vs3Information.this.getApplication();
                if (!ifClicked) {
                    appli.setFlag(true);
                    appli.setMap(toBePassedMap);
                    fab.setImageDrawable(getResources().getDrawable(android.R.drawable.btn_star_big_off));
                    Snackbar.make(view, "this game is added to your today's timeline", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                    ifClicked = true;
                }
                else{
                    appli.setIntentDelete(true);
                    fab.setImageDrawable(getResources().getDrawable(android.R.drawable.ic_input_add));
                    //fab.setBackgroundTintList (ColorStateList.valueOf(Color.WHITE));
                    Snackbar.make(view, "this game is deleted from your today's timeline", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                    ifClicked = false;
                }
            }
        });
    }
/*
    @Override
    protected void onResume(){
        super.onResume();
        if(ifClicked){
            fab.setImageDrawable(getResources().getDrawable(android.R.drawable.btn_star_big_off));
        }
        else{
            fab.setImageDrawable(getResources().getDrawable(android.R.drawable.ic_input_add));
        }
    }
*/
    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        int itemId = item.getItemId();
        if (itemId == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
