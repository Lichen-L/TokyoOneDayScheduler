package com.utut.olympicschedule;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

public class timeLine extends AppCompatActivity {
    static String datePassed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_line);

        Intent intent = getIntent();
        datePassed = intent.getStringExtra("date");

        Toolbar toolbar = findViewById(R.id.toolbarTimeLine);
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolbarLayout = findViewById(R.id.toolbarLayoutTimeline);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarLayout.setTitle(datePassed);
        toolbarLayout.setTitleEnabled(true);
        toolbarLayout.setExpandedTitleColor(Color.WHITE);
        toolbarLayout.setCollapsedTitleTextColor(Color.WHITE);

        FloatingActionButton fab = findViewById(R.id.fabTimeLine);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(timeLine.this, chooseSportToAdd.class);
                intent.putExtra("date",datePassed);
                startActivity(intent);
            }
        });

        FrequentUsedMethods frequentUsedMethods = new FrequentUsedMethods(this);
        frequentUsedMethods.setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
/*
        Button slotButton = frequentUsedMethods.createButtonWithConstraint(R.id.ConsLayoutTimeline, this,"TEST", 300, 40, R.id.lineEight, R.id.textEight, 20, 10);
        slotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // DO SOMETHING！
            }
      });
*/
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        int itemId = item.getItemId();
        if (itemId == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}
